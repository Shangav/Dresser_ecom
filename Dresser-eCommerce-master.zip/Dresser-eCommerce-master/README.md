# Dresser-eCommerce
A data-driven eCommerce website. An online clothing store, complete with shopping cart, wish list, searching and rating system.
It utilize Django as middleware to connect back-end Amazon RDS MySQL database and front-end Twitter Bootstrap-based webpage GUI.
